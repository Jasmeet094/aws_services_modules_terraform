import json
import os
import requests

def lambda_handler(event, context):
  print(event)
  response = requests.get('https://api.github.com')
  print (response.status_code)
  if response.status_code == 200:
    print('Success!')
  else
    print('Not Found.')
    
  return {
    'statusCode': 200,
    'body': json.dumps('Hello from ' + os.environ['SUBJECT'] + '!')
  }
